# =================================================================
# SKRIP 5: ANALISIS REGRESI LINEAR SEDERHANA (Prediksi Churn)
# =================================================================

# -----------------------------------------------------------------
# Langkah 0: Persiapan
# -----------------------------------------------------------------
if (!exists("data_bersih")) {
  # Memuat data secara otomatis jika belum ada di environment
  if(file.exists("data_statpro.csv")) {
    library(tidyverse)
    data_bersih <- read_csv("data_statpro.csv")
  } else {
    stop("File 'data_statpro.csv' tidak ditemukan. Pastikan file ada di folder kerja Anda.")
  }
}

# Menentukan Variabel agar tidak error (Copy-paste nama kolom tepat sesuai CSV)
var_dependen <- "Tingkat_Churn_Persen"
var_independen <- "Biaya_Akuisisi_Pelanggan_Juta_IDR"

# Validasi keberadaan kolom
if(!all(c(var_dependen, var_independen) %in% names(data_bersih))) {
  stop("Nama kolom tidak cocok. Periksa penulisan variabel X dan Y Anda.")
}

# -----------------------------------------------------------------
# Langkah 1: Membangun Model Regresi Linear
# -----------------------------------------------------------------
# Menggunakan backticks (``) di formula untuk menangani nama kolom yang panjang
formula_regresi <- as.formula(paste0("`", var_dependen, "` ~ `", var_independen, "`"))
model_regresi <- lm(formula_regresi, data = data_bersih)

# -----------------------------------------------------------------
# Langkah 2: Interpretasi Hasil
# -----------------------------------------------------------------
summary_model <- summary(model_regresi)
intercept_val <- coef(model_regresi)[1]
slope_val <- coef(model_regresi)[2]
adj_r_squared <- summary_model$adj.r.squared

cat("\n--- RINGKASAN MODEL REGRESI ---\n")
print(summary_model)

cat("\n--- INTERPRETASI MANAJERIAL ---\n")
cat("1. Persamaan: Churn (%) =", round(intercept_val, 2), "+ (", round(slope_val, 2), "* Biaya Akuisisi)\n")
cat("2. Makna Slope: Setiap kenaikan 1 Juta IDR pada biaya akuisisi, churn diprediksi", 
    ifelse(slope_val < 0, "TURUN", "NAIK"), "sebesar", abs(round(slope_val, 2)), "%\n")
cat("3. Akurasi (Adj R-Squared):", round(adj_r_squared * 100, 2), "% variasi churn dijelaskan oleh biaya akuisisi.\n")

# -----------------------------------------------------------------
# Langkah 3: Visualisasi
# -----------------------------------------------------------------
plot_regresi <- ggplot(data_bersih, aes(x = .data[[var_independen]], y = .data[[var_dependen]])) +
  geom_point(alpha = 0.5, color = "steelblue") +
  geom_smooth(method = "lm", se = TRUE, color = "darkred", fill = "pink") + 
  labs(
    title = "Garis Regresi: Biaya Akuisisi vs Tingkat Churn",
    subtitle = paste("R-Squared:", round(adj_r_squared, 3)),
    x = "Biaya Akuisisi (Juta IDR)",
    y = "Tingkat Churn (%)"
  ) +
  theme_minimal()

print(plot_regresi)

