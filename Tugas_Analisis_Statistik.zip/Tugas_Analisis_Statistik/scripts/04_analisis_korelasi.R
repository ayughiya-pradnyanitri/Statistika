# =================================================================
# SKRIP 4: ANALISIS KORELASI (Biaya Akuisisi vs Tingkat Churn)
# =================================================================

# -----------------------------------------------------------------
# Langkah 0: Persiapan
# -----------------------------------------------------------------
if (!exists("data_bersih")) {
  stop("Variabel 'data_bersih' tidak ditemukan. Jalankan Skrip 1 terlebih dahulu.")
}

# Menetapkan variabel untuk dianalisis
var_x <- "Biaya_Akuisisi_Pelanggan_Juta_IDR"
var_y <- "Tingkat_Churn_Persen"

# -----------------------------------------------------------------
# Langkah 1: Visualisasi Hubungan dengan Scatter Plot
# -----------------------------------------------------------------
scatter_plot <- ggplot(data_bersih, aes(x = .data[[var_x]], y = .data[[var_y]])) +
  geom_point(alpha = 0.5, color = "#34495e") +
  geom_smooth(method = "lm", color = "#e67e22", fill = "#f39c12") + 
  labs(
    title = "Hubungan Biaya Akuisisi vs Tingkat Churn",
    subtitle = "Garis oranye menunjukkan tren hubungan antara biaya dan loyalitas",
    x = "Biaya Akuisisi Pelanggan (Juta IDR)",
    y = "Tingkat Churn (%)"
  ) +
  theme_minimal()

print(scatter_plot)

# -----------------------------------------------------------------
# Langkah 2: Menghitung Koefisien Korelasi
# -----------------------------------------------------------------
# Catatan: Jika pada Skrip 3 data Anda TIDAK NORMAL, ganti method menjadi "spearman"
metode_uji <- "pearson" 

correlation_test <- cor.test(data_bersih[[var_x]], data_bersih[[var_y]], method = metode_uji)

cat("\n--- HASIL ANALISIS KORELASI ---\n")
cat("Variabel X:", var_x, "\n")
cat("Variabel Y:", var_y, "\n\n")

# Interpretasi Hasil
cor_value <- correlation_test$estimate
p_value <- correlation_test$p.value

cat("Koefisien Korelasi (r):", round(cor_value, 3), "\n")
cat("P-Value               :", round(p_value, 5), "\n\n")

# Logika Interpretasi
kekuatan <- cut(abs(cor_value), breaks=c(0, 0.1, 0.4, 0.7, 1), labels=c("sangat lemah", "lemah", "sedang", "kuat"))
arah <- if(cor_value > 0) "Positif (Searah)" else "Negatif (Berlawanan)"

cat("INTERPRETASI:\n")
cat("- Arah Hubungan:", arah, "\n")
cat("- Kekuatan     :", as.character(kekuatan), "\n")

if(p_value <= 0.05) {
  cat("- Kesimpulan   : Hubungan Signifikan secara statistik.\n")
} else {
  cat("- Kesimpulan   : Hubungan TIDAK signifikan secara statistik.\n")
}

