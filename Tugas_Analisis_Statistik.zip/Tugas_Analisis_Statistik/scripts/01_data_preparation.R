# =================================================================
# SKRIP 1: PERSIAPAN DATA (Disesuaikan untuk data_statpro.csv)
# =================================================================

library(tidyverse)

# -----------------------------------------------------------------
# Langkah 2: Memuat Dataset
# -----------------------------------------------------------------
# Menggunakan file yang diunggah: data_statpro.csv
tryCatch({
  file_path <- "data_statpro.csv" # Sesuaikan path jika di folder lokal
  data <- read_csv(file_path)
  print(paste("Dataset berhasil dimuat:", file_path))
}, error = function(e) {
  print("Gagal memuat dataset. Pastikan file 'data_statpro.csv' berada di direktori kerja Anda.")
})

# -----------------------------------------------------------------
# Langkah 3: Pemeriksaan Awal Data (Fokus: Biaya Akuisisi & Churn)
# -----------------------------------------------------------------
# Memilih kolom spesifik untuk dilihat
data_fokus <- data %>% 
  select(Biaya_Akuisisi_Pelanggan_Juta_IDR, Tingkat_Churn_Persen)

print("Menampilkan ringkasan statistik untuk Biaya Akuisisi dan Churn:")
summary(data_fokus)

# -----------------------------------------------------------------
# Langkah 4: Pembersihan Data
# -----------------------------------------------------------------
# Mengecek nilai kosong khusus pada dua kolom target
missing_akuisisi <- sum(is.na(data$Biaya_Akuisisi_Pelanggan_Juta_IDR))
missing_churn <- sum(is.na(data$Tingkat_Churn_Persen))

print(paste("Missing values di Biaya Akuisisi:", missing_akuisisi))
print(paste("Missing values di Tingkat Churn:", missing_churn))

# Membersihkan data (menghapus baris jika ada NA di kolom target)
data_bersih <- data %>%
  filter(!is.na(Biaya_Akuisisi_Pelanggan_Juta_IDR), 
         !is.na(Tingkat_Churn_Persen))

print("Persiapan data selesai. Variabel 'data_bersih' siap digunakan.")

