# =================================================================
# SKRIP 2: ANALISIS STATISTIK DESKRIPTIF (Custom untuk data_statpro.csv)
# =================================================================

# -----------------------------------------------------------------
# Langkah 0: Persiapan
# -----------------------------------------------------------------
if (!exists("data_bersih")) {
  # Mengasumsikan data_bersih sudah dibuat di memori dari langkah sebelumnya
  # Jika belum, pastikan Anda sudah menjalankan Skrip 1
  stop("Variabel 'data_bersih' tidak ditemukan. Jalankan Skrip 1 (Persiapan Data) terlebih dahulu.")
}

# PILIH KOLOM DI SINI:
# Opsi 1: "Biaya_Akuisisi_Pelanggan_Juta_IDR"
# Opsi 2: "Tingkat_Churn_Persen"
kolom_analisis <- "Biaya_Akuisisi_Pelanggan_Juta_IDR" 

# -----------------------------------------------------------------
# Langkah 1 & 2: Ukuran Pemusatan dan Sebaran Data
# -----------------------------------------------------------------
get_mode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

cat("\n--- HASIL ANALISIS UNTUK:", kolom_analisis, "---\n")
print(paste("Mean          :", round(mean(data_bersih[[kolom_analisis]], na.rm = TRUE), 2)))
print(paste("Median        :", round(median(data_bersih[[kolom_analisis]], na.rm = TRUE), 2)))
print(paste("Modus         :", get_mode(data_bersih[[kolom_analisis]])))
print(paste("Standar Deviasi:", round(sd(data_bersih[[kolom_analisis]], na.rm = TRUE), 2)))
print("Ringkasan 5 Angka:")
print(summary(data_bersih[[kolom_analisis]]))

# -----------------------------------------------------------------
# Langkah 3: Visualisasi Data
# -----------------------------------------------------------------
# A. Histogram
hist_plot <- ggplot(data_bersih, aes(x = .data[[kolom_analisis]])) +
  geom_histogram(bins = 30, fill = "#3498db", color = "white") +
  geom_vline(aes(xintercept = mean(data_bersih[[kolom_analisis]])), 
             color = "red", linetype = "dashed", size = 1) +
  labs(
    title = paste("Distribusi", gsub("_", " ", kolom_analisis)),
    subtitle = "Garis merah menunjukkan rata-rata (Mean)",
    x = "Nilai",
    y = "Jumlah Startup"
  ) +
  theme_minimal()

print(hist_plot)

# B. Boxplot
box_plot <- ggplot(data_bersih, aes(y = .data[[kolom_analisis]])) +
  geom_boxplot(fill = "#2ecc71", color = "#27ae60") +
  labs(
    title = paste("Boxplot", gsub("_", " ", kolom_analisis)),
    y = "Nilai"
  ) +
  theme_minimal()

print(box_plot)

