# =================================================================
# SKRIP 3: UJI NORMALITAS (Disesuaikan untuk data_statpro.csv)
# =================================================================

# -----------------------------------------------------------------
# Langkah 0: Persiapan
# -----------------------------------------------------------------
if (!exists("data_bersih")) {
  stop("Variabel 'data_bersih' tidak ditemukan. Jalankan Skrip 1 terlebih dahulu.")
}

# Tentukan kolom yang ingin diuji (pilih salah satu)
# 1. "Biaya_Akuisisi_Pelanggan_Juta_IDR"
# 2. "Tingkat_Churn_Persen"
kolom_uji <- "Biaya_Akuisisi_Pelanggan_Juta_IDR" 

# -----------------------------------------------------------------
# Langkah 1: Uji Visual (Q-Q Plot)
# -----------------------------------------------------------------
# Q-Q Plot: Jika titik-titik menempel pada garis merah, data Anda Normal.
qq_plot <- ggplot(data_bersih, aes(sample = .data[[kolom_uji]])) +
  stat_qq(color = "#2c3e50") +
  stat_qq_line(color = "#e74c3c", linetype = "dashed", size = 1) +
  labs(
    title = paste("Q-Q Plot:", gsub("_", " ", kolom_uji)),
    subtitle = "Data Normal jika titik-titik mengikuti garis diagonal merah",
    x = "Kuantil Teoritis",
    y = "Kuantil Sampel"
  ) +
  theme_minimal()

print(qq_plot)

# -----------------------------------------------------------------
# Langkah 2: Uji Statistik (Shapiro-Wilk)
# -----------------------------------------------------------------
cat("\n--- HASIL UJI SHAPIRO-WILK UNTUK:", kolom_uji, "---\n")

# Catatan: Shapiro-Wilk terbatas untuk 5000 observasi. 
# Jika data Anda lebih besar, kita gunakan p-value dari inspeksi visual.
if(nrow(data_bersih) <= 5000) {
  uji_shapiro <- shapiro.test(data_bersih[[kolom_uji]])
  print(uji_shapiro)
  
  if (uji_shapiro$p.value > 0.05) {
    cat("HASIL: Data Terdistribusi Normal (p > 0.05)\n")
    cat("Saran: Anda boleh menggunakan Korelasi Pearson.\n")
  } else {
    cat("HASIL: Data TIDAK Terdistribusi Normal (p <= 0.05)\n")
    cat("Saran: Gunakan Korelasi Spearman (non-parametrik).\n")
  }
} else {
  print("Data terlalu besar untuk Shapiro-Wilk (>5000 baris).")
  print("Gunakan inspeksi visual pada Q-Q Plot di atas.")
}

